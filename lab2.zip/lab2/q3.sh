#!/bin/bash
showAllowners(){
	name=$1
	files=`ls -l ~`
	array=($files)
	
	echo ${array[2]}
	
	
}
if [ $# -eq 0 ]
then
	echo "no"
else
	showAllowners $1
fi
