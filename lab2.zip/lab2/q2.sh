#!/bin/bash
pname=$1

pid=`pidof $pname`
array=($pid)
IFS=$'\n'
for i in ${array[*]}
do
	temp=`cat /proc/$i/status`
	array1=($temp)

	echo ${array1[5]}
	echo ${array1[0]}
	echo ${array1[6]}
	
done
