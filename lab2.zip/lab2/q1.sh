#!/bin/bash

showtable(){
		
		num1=$1
		starting=$2
		ending=$3		

		while [ $starting -le $ending ]
		do
			echo "$num1" X "$starting=`expr $num1 \* $starting`"
			starting=`expr $starting + 1`	
		done
	}

#case 1
if [ $# -eq 0 ]
then
	echo "NO Arguents Given"
fi
#case 2
if [ $# -ge 6 ]
then
	echo "Arguents more then 6"

fi
#case 3
if [ $# -eq 1 ]
then
	showtable $1 1 10 $#
fi
#case4
if [ $# -eq 3 ]
then
	if [ $2 = "-s" ]
	then
		showtable $1 3 10
	fi
	if [ $2 = "-e" ]
	then
		showtable $1 1 $3
	fi
fi





