#define 8*8 matrix
matrix=[
[0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0],
[0,0,0,0,0,0,0,0]
]

inputMatrix=[
    [0,0],
    [0,1]
    ]


def check(i,j):
    x1=i
    y1=j+1
    x2=i+1
    y2=j
    x3=i+1
    y3=j+1
        
    if 0<=x1<8 and 0<=y1<8 and 0<=x2<8 and 0<=y2<8 and 0<=x3<8 and 0<=y3<8:
        if matrix[x1][y1]==inputMatrix[0][1] and matrix[x2][y2]==inputMatrix[1][0] and matrix[x3][y3]==inputMatrix[1][1]:
            return 1
        else:
            return 0
    else:
        return 0
    
# Match 2*2 matrix with 8*8 matrix  
var=0
for i in range(8):
    for j in range(8):
        if matrix[i][j]==inputMatrix[0][0]:
            if check(i,j)==1:
                print ("Matrix found at (",i,j,")")
                var=1

if var==0:
    print ("Matrix not found ")
