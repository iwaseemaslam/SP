

import sys

first_name = sys.argv[1]
last_name  = sys.argv[2]

print("Hello" +" "+ first_name + " "+ last_name)

from urllib2 import urlopen as uReq
from bs4 import BeautifulSoup as soup
my_url='https://propakistani.pk/category/sports/'

uClient=uReq(my_url)
page_html=uClient.read()
uClient.close()


page_soup = soup(page_html, "html.parser")
page_soup.find(first_name).findNext()


container =  page_soup.findAll("a")
