from bs4 import BeautifulSoup
from urllib2 import urlopen 
import urllib2
import requests

res = requests.get('https://download.quranicaudio.com/quran/')
bs = BeautifulSoup(res.text,"html.parser")
links=bs.select('a')
for i in links:
    link=i['href']
    new = "https://download.quranicaudio.com/quran/"+link
    
    res1=requests.get('new')