#!/bin/bash
file=$1
counter=0

 
lower_case(){
	echo "Enter string : "
	read str
	str=${str,,}
	echo "String in Lower case : "$str
	}
	
root(){
				if [ `whoami` != 'root' ]
				then
					echo "You are not root."
				else
					echo "You are root."
				fi
	}
	
user(){
	
			echo "Enter Username : "
			read user
		    id=" `grep -c $user /etc/passwd `"

			if [ $id -eq 1 ]
			then
					echo "User exist"
			else
					echo "User does not exist"
			fi
	}

lower_case
root
user
