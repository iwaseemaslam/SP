#!/bin/bash
file=$1
declare -i counter
counter=0 
while read number
do
	counter=counter+1
	remainder=$(( counter%2 ))

	if [ $remainder -eq 0 ] 
	then
		echo $number >> evenfile.txt 
	else
		echo $number >> oddfile.txt
	fi

done < $file
