#!/bin/bash
sort -u $1 | tee $1


